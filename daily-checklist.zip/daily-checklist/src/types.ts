
export type TaskStatus = 'Pending' | 'Selesai'

export interface Task {
  id: string
  date: string
  item: string
  petugas: string
  note?: string
  status: TaskStatus
  photo?: string
}


import type { Task } from './types'

const KEY = 'daily-checklist-tasks'

export function loadTasks(): Task[] {
  const raw = localStorage.getItem(KEY)
  if (!raw) return sampleTasks()
  try { return JSON.parse(raw) as Task[] } catch { return sampleTasks() }
}

export function saveTasks(tasks: Task[]) {
  localStorage.setItem(KEY, JSON.stringify(tasks))
}

function todayISO(): string {
  const d = new Date(); const tzOff = d.getTimezoneOffset() * 60000
  return new Date(d.getTime() - tzOff).toISOString().slice(0,10)
}

function sampleTasks(): Task[] {
  const today = todayISO()
  return [
    { id: '1', date: today, item: 'Pengecekan pompa air', petugas: 'Bayu', status: 'Pending' },
    { id: '2', date: today, item: 'Pengecekan compressor', petugas: 'Iwang', status: 'Pending' },
    { id: '3', date: today, item: 'Pelumasan mesin produksi', petugas: 'Deni', status: 'Pending' },
    { id: '4', date: today, item: 'Pemeriksaan panel listrik utama', petugas: 'Haerul', status: 'Pending' },
    { id: '5', date: today, item: 'Uji genset & ketersediaan BBM', petugas: 'Hildan', status: 'Pending' },
  ]
}

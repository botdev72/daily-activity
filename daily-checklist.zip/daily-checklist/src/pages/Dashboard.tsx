
import { useMemo, useState } from 'react'
import { loadTasks } from '@/store'
import type { Task } from '@/types'
import ProgressBar from '@/components/ProgressBar'
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip } from 'recharts'

function groupBy<T, K extends string | number>(arr: T[], key: (x:T)=>K) {
  return arr.reduce((acc, cur) => {
    const k = key(cur)
    ;(acc[k] ||= []).push(cur)
    return acc
  }, {} as Record<K, T[]>)
}

export default function Dashboard() {
  const [date, setDate] = useState<string>('')
  const [petugas, setPetugas] = useState<string>('')
  const tasks = loadTasks()

  const petugasList = Array.from(new Set(tasks.map(t => t.petugas)))
  const dateList = Array.from(new Set(tasks.map(t => t.date))).sort((a,b)=>a.localeCompare(b))

  const filtered = useMemo(() => tasks.filter(t =>
    (!date || t.date === date) && (!petugas || t.petugas === petugas)
  ), [tasks, date, petugas])

  const total = filtered.length
  const done = filtered.filter(t => t.status === 'Selesai').length
  const progress = total ? Math.round((done/total)*100) : 0

  const pieData = [
    { name: 'Selesai', value: done },
    { name: 'Pending', value: Math.max(0, total - done) },
  ]
  const COLORS = ['#16a34a', '#dc2626']

  const byPetugas = groupBy(filtered, t => t.petugas)

  return (
    <div className="space-y-6">
      <div className="card flex flex-wrap gap-3 items-end">
        <div>
          <div className="label">Tanggal</div>
          <select className="input" value={date} onChange={e => setDate(e.target.value)}>
            <option value="">Semua</option>
            {dateList.map(d => <option key={d} value={d}>{d}</option>)}
          </select>
        </div>
        <div>
          <div className="label">Petugas</div>
          <select className="input" value={petugas} onChange={e => setPetugas(e.target.value)}>
            <option value="">Semua</option>
            {petugasList.map(p => <option key={p} value={p}>{p}</option>)}
          </select>
        </div>
        <div className="ml-auto min-w-[260px]">
          <div className="label mb-1">Progress</div>
          <ProgressBar value={progress} />
          <div className="text-xs text-gray-500 mt-1">{done} / {total} selesai ({progress}%)</div>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div className="card h-72">
          <div className="font-semibold mb-2">Status Pekerjaan</div>
          <div className="w-full h-56">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie data={pieData} dataKey="value" nameKey="name" outerRadius={80} label>
                  {pieData.map((entry, index) => <Cell key={index} fill={COLORS[index % COLORS.length]} />)}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        <div className="card">
          <div className="font-semibold mb-2">Rekap per Petugas</div>
          <div className="space-y-2">
            {Object.entries(byPetugas).map(([p, arr]) => {
              const t = arr.length
              const d = arr.filter(x => x.status === 'Selesai').length
              const pr = t ? Math.round((d/t)*100) : 0
              return (
                <div key={p} className="border rounded-xl p-3">
                  <div className="flex items-center justify-between">
                    <div className="font-medium">{p}</div>
                    <div className="text-xs text-gray-500">{d}/{t} selesai</div>
                  </div>
                  <div className="mt-2"><ProgressBar value={pr} /></div>
                </div>
              )
            })}
            {Object.keys(byPetugas).length === 0 && <div className="text-sm text-gray-500">Tidak ada data.</div>}
          </div>
        </div>
      </div>

      <div className="card">
        <div className="font-semibold mb-2">Detail Checklist</div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead>
              <tr className="text-left border-b">
                <th className="py-2 pr-3">Tanggal</th>
                <th className="py-2 pr-3">Item</th>
                <th className="py-2 pr-3">Petugas</th>
                <th className="py-2 pr-3">Status</th>
                <th className="py-2 pr-3">Catatan</th>
                <th className="py-2 pr-3">Bukti</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((t: Task) => (
                <tr key={t.id} className="border-b align-top">
                  <td className="py-2 pr-3">{t.date}</td>
                  <td className="py-2 pr-3">{t.item}</td>
                  <td className="py-2 pr-3">{t.petugas}</td>
                  <td className="py-2 pr-3">
                    <span className={`badge ${t.status === 'Selesai' ? 'badge-green' : 'badge-red'}`}>{t.status}</span>
                  </td>
                  <td className="py-2 pr-3 max-w-[300px]">{t.note ?? '-'}</td>
                  <td className="py-2 pr-3">{t.photo ? <img src={t.photo} className="h-16 rounded border" /> : '-'}</td>
                </tr>
              ))}
              {filtered.length === 0 && (
                <tr><td className="py-4 text-gray-500" colSpan={6}>Tidak ada data untuk filter ini.</td></tr>
              )}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  )
}

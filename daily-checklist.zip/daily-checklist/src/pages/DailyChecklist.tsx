
import { useEffect, useMemo, useState } from 'react'
import TaskCard from '@/components/TaskCard'
import { loadTasks, saveTasks } from '@/store'
import type { Task } from '@/types'

function toISO(d: Date) {
  const tzOff = d.getTimezoneOffset() * 60000
  return new Date(d.getTime() - tzOff).toISOString().slice(0,10)
}

export default function DailyChecklist() {
  const [tasks, setTasks] = useState<Task[]>(() => loadTasks())
  const [date, setDate] = useState<string>(() => toISO(new Date()))
  const [petugas, setPetugas] = useState<string>('')

  useEffect(() => { saveTasks(tasks) }, [tasks])

  const filtered = useMemo(() => tasks.filter(t => t.date === date && (!petugas || t.petugas === petugas)), [tasks, date, petugas])
  const petugasList = Array.from(new Set(tasks.map(t => t.petugas)))

  const updateTask = (nt: Task) => setTasks(prev => prev.map(t => t.id === nt.id ? nt : t))

  const addTask = () => {
    const item = prompt('Nama item pekerjaan:')
    const nama = prompt('Nama petugas:', petugas || petugasList[0] || '')
    if (!item || !nama) return
    const id = String(Date.now())
    setTasks(prev => [...prev, { id, date, item, petugas: nama, status: 'Pending' }])
  }

  return (
    <div className="space-y-4">
      <div className="card flex flex-wrap gap-3 items-end">
        <div>
          <div className="label">Tanggal</div>
          <input className="input" type="date" value={date} onChange={e => setDate(e.target.value)} />
        </div>
        <div>
          <div className="label">Petugas</div>
          <select className="input" value={petugas} onChange={e => setPetugas(e.target.value)}>
            <option value="">Semua</option>
            {petugasList.map(p => <option key={p} value={p}>{p}</option>)}
          </select>
        </div>
        <div className="ml-auto">
          <button className="btn btn-primary" onClick={addTask}>+ Tambah Pekerjaan</button>
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        {filtered.map(task => (
          <TaskCard key={task.id} task={task} onChange={updateTask} />
        ))}
        {filtered.length === 0 && (
          <div className="card text-sm text-gray-500">Belum ada data untuk filter ini.</div>
        )}
      </div>
    </div>
  )
}

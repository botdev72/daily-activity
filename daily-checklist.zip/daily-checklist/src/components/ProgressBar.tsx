
interface Props { value: number }
export default function ProgressBar({ value }: Props) {
  return (
    <div className="w-full h-3 bg-gray-200 rounded-full overflow-hidden">
      <div className="h-3 bg-green-600" style={{ width: `${Math.min(100, Math.max(0, value))}%` }} />
    </div>
  )
}


import { useRef } from 'react'
import type { Task } from '@/types'

interface Props {
  task: Task
  onChange: (task: Task) => void
}

export default function TaskCard({ task, onChange }: Props) {
  const fileRef = useRef<HTMLInputElement | null>(null)

  const onFile = async (file: File) => {
    const toDataURL = (f: File) => new Promise<string>((res, rej) => {
      const r = new FileReader(); r.onload = () => res(String(r.result)); r.onerror = rej; r.readAsDataURL(f);
    })
    const dataUrl = await toDataURL(file)
    onChange({ ...task, status: 'Selesai', photo: dataUrl })
  }

  return (
    <div className="card">
      <div className="flex items-start justify-between gap-4">
        <div>
          <div className="font-semibold text-lg">{task.item}</div>
          <div className="text-sm text-gray-500">Petugas: {task.petugas} • {task.date}</div>
        </div>
        <div>
          <span className={`badge ${task.status === 'Selesai' ? 'badge-green' : 'badge-red'}`}>{task.status}</span>
        </div>
      </div>

      {task.photo ? (
        <img src={task.photo} alt="Bukti" className="rounded-xl mt-3 max-h-64 object-contain w-full border" />
      ) : (
        <div className="mt-3">
          <label className="label">Upload Foto Bukti</label>
          <div className="flex items-center gap-2">
            <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={e => e.target.files && onFile(e.target.files[0])} />
            <button className="btn btn-primary" onClick={() => fileRef.current?.click()}>Pilih Foto</button>
            <span className="text-xs text-gray-500">Wajib untuk menandai selesai</span>
          </div>
        </div>
      )}

      <div className="mt-3">
        <label className="label">Catatan</label>
        <textarea className="input h-20" placeholder="Keterangan/temuan..." value={task.note ?? ''} onChange={e => onChange({ ...task, note: e.target.value })} />
      </div>
    </div>
  )
}


import { Outlet, NavLink } from 'react-router-dom'

export default function App() {
  return (
    <div>
      <header className="bg-white border-b">
        <div className="container flex items-center justify-between py-3">
          <div className="font-bold text-lg">ME Daily Activity</div>
          <nav className="flex gap-2">
            <NavLink to="/dashboard" className={({isActive}) => (isActive ? 'btn btn-primary' : 'btn btn-outline')}>Dashboard</NavLink>
            <NavLink to="/checklist" className={({isActive}) => (isActive ? 'btn btn-primary' : 'btn btn-outline')}>Checklist</NavLink>
          </nav>
        </div>
      </header>
      <main className="container py-6">
        <Outlet />
      </main>
      <footer className="container text-xs text-gray-500 py-8">
        PT. Raffles Pacific Harvest Garut • Mechanical & Electrical
      </footer>
    </div>
  )
}
